__all__ =[
    "confocal_controls"
]

from experimental_configuration.hardware_interfaces import *

###############################################################################################################
# Confocal Controls 
###############################################################################################################

# Setting the default locations to 0 This shouldn't affect the functionality of the fsm but this 
# is not something we want to do for the attocube scanner in case the probe is close to the sample
confocal_x._position_m = 0
confocal_y._position_m = 0
confocal_z._position_m = 0
    
from NV_ABJ.experimental_logic.confocal_scanning import ConfocalControls
# Setting up controls 
confocal_controls = ConfocalControls(confocal_x,confocal_y,confocal_z,apd_1)
