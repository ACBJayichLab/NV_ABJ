__all__ = [
    "confocal_x", "confocal_y", "confocal_z",
    "apd_1",
    "pulse_blaster","pulse_generator_controlled_devices",
    "green_aom_trigger", "apd_trigger_1", 
    "rf_1","rf_1_iq_neg_y","rf_1_iq_pos_y","rf_1_iq_neg_x","rf_1_iq_pos_x",
    "signal_generator_1",
    "green_photo_diode",]

###############################################################################################################
# FSM Controls 
###############################################################################################################
from NV_ABJ.hardware_interfaces.scanner.ni_daq_scanner.ni_daq_scanner import NiDaqSingleAxisScanner
# Adding FSM controls
confocal_x = NiDaqSingleAxisScanner(conversion_volts_per_meter_setting=XXX,# Volts(V)/distance (m)
                                              device_name_output="XXX", #Slot this the x confocal control is plugged into the DAQ i.e. PXI1SlotXXX
                                              channel_name_output="XXX", # ao0 Analog output number
                                              position_limits_m=(XXX,XXX)) #(Lower bound, upper bound)

confocal_y = NiDaqSingleAxisScanner(conversion_volts_per_meter_setting=XXX,
                                              device_name_output="XXX",
                                              channel_name_output="XXX",
                                              position_limits_m=(XXX,XXX))


confocal_z = NiDaqSingleAxisScanner(conversion_volts_per_meter_setting=XXX,
                                              device_name_output="XXX",
                                              channel_name_output="XXX",
                                              position_limits_m=(XXX,XXX))

###############################################################################################################
# Photon Counter
###############################################################################################################
from NV_ABJ.hardware_interfaces.photon_counter.ni_daq_counters.ni_photon_counter_daq_controlled import NiPhotonCounterDaqControlled

# Adding the photon counter
apd_1 = NiPhotonCounterDaqControlled(device_name="XXX", #Slot on Daq "PXI1SlotXXX"
                                                counter_pfi="pfi0", # This should almost always be counter pfi0 but it's what the apd is connected to 
                                                trigger_pfi="XXX") # This is the port on the daq that the pulse blaster connects to 

###############################################################################################################
# Photon Diode 
###############################################################################################################
from NV_ABJ.hardware_interfaces.photo_diodes.ni_daq_photo_diode.ni_daq_photo_diode import NiDaqPhotoDiode

# This function will allow for the conversion of a voltage to watts of power 
def green_laser_power_func(voltage:float)->float:
    power_w =  (voltage)#*Fitted_Slope + Fitted_Y_Intercept 
    return power_w

green_photo_diode = NiDaqPhotoDiode(device_name="XXX", # Daq card slot PXI1Slot4
                                photo_diode_channel="XXX", # Analog output
                                conversion_function=green_laser_power_func)

###############################################################################################################
# Pulse Blaster 
###############################################################################################################
from NV_ABJ.hardware_interfaces.pulse_generators.spbicl_pulse_blaster.spbicl_pulse_blaster import SpbiclPulseBlaster
""" For the pulse blaster to work you either need to add the "spbicl.exe" to your environment variables or you need to give the path to a
third party folder. Personally I recommend the environment variables. If spbicl_path=None below it will use the environment variables. 

Using pulse blaster with environment variables:
1) Download spbicl.exe from https://www.spincore.com/support/spinapi/
2) Locate the folder you have downloaded this to
3) Follow this https://www.architectryan.com/2018/03/17/add-to-the-path-on-windows-10/

you can check it is working by opening a NEW command line window and typing: spbicl

If an error "command not recognized" is displayed then you need to retry adding to the environment variables 
"""
pulse_blaster = SpbiclPulseBlaster(spbicl_path=None) 

###############################################################################################################
# Sequence Controlled Devices 
###############################################################################################################
from NV_ABJ.experimental_logic.sequence_generation.sequence_generation import SequenceDevice

rf_1 = SequenceDevice(address=XXX, # the port the microwave switch is plugged into on the pulse blaster 
                                    device_label="Microwave Switch Trigger",
                                    delayed_to_on_ns=0,
                                    device_status = False)

rf_1_iq_neg_y = SequenceDevice(address=XXX, # Port that the IQ -Y is plugged into on the pulse blaster
                                    device_label="RF 1 IQ -Y",
                                    delayed_to_on_ns=0,
                                    device_status = False)

rf_1_iq_pos_y = SequenceDevice(address=XXX,# Port that the IQ +Y is plugged into on the pulse blaster
                                    device_label="RF 1 IQ +Y",
                                    delayed_to_on_ns=0,
                                    device_status = False)

rf_1_iq_neg_x = SequenceDevice(address=XXX,# Port that the IQ -X is plugged into on the pulse blaster
                                    device_label="RF 1 IQ -X",
                                    delayed_to_on_ns=0,
                                    device_status = False)

rf_1_iq_pos_x = SequenceDevice(address=XXX,# Port that the IQ +X is plugged into on the pulse blaster
                                    device_label="RF 1 IQ +X",
                                    delayed_to_on_ns=0,
                                    device_status = False)

green_aom_trigger = SequenceDevice(address=XXX, # Port that the green AOM is plugged into on the pulse blaster
                                   device_label="Green AOM Trigger",
                                   delayed_to_on_ns=XXX,# Delay that the green AOM has with 
                                   device_status = False,
                                   inverted_output=False) # If you have an inverted AOM like a Mog AOM driver check True if it is a normal AOM driver leave as false 

apd_trigger_1 = SequenceDevice(address = XXX, # Port the APD trigger is plugged into (This should be a cable from the pulse blaster to the apd trigger definition above i.e. pulse blaster port 5 to Daq pfi1)
                                    device_label="APD Readout Trigger",
                                    delayed_to_on_ns=0,
                                    device_status = False)

pulse_generator_controlled_devices = [rf_1,rf_1_iq_neg_y,rf_1_iq_pos_y,rf_1_iq_pos_x,rf_1_iq_pos_x,green_aom_trigger,apd_trigger_1]

###############################################################################################################
# Microwave Sources 
###############################################################################################################
from NV_ABJ.hardware_interfaces.microwave_sources.sg380.sg380 import SG380

srs_address = XXX # The address that the SRS is connected to this is ofter in the format 'GPIB0::27::INSTR' where 27 is replaced with what your SRS is set to for a GPIB connection
signal_generator_1 = SG380(gpib_address=srs_address)       