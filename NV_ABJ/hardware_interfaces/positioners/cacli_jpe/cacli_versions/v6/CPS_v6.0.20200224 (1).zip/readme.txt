JPE Cryogenic Positioning Systems Controller (CPSC) - User Software version 6.0.20200224

------------------------------------------------------------------------------------------
Important note regarding CAControlSystem.exe: 
This is v5.3 of the GUI. It only supports basic movement functions (CW Continuous / CCW
Continuous / CW Steps / CCW Steps) with CADM2 modules!
------------------------------------------------------------------------------------------

All contents of this zip file: (C) JPE B.V.
This software is provided 'As Is' without any express or implied warranty of any kind.

For more information, please visit http://www.jpe.nl or mail to contact@jpe.nl.
