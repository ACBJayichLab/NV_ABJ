#pragma once
#ifndef __USB_ENDPOINTS_H__
#define __USB_ENDPOINTS_H__
#define EP1OUT 0x01
#define EP2OUT 0x02
#define EP6IN  0x86
#endif
